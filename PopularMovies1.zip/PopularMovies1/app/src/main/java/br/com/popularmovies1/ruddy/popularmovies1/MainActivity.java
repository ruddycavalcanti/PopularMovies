package br.com.popularmovies1.ruddy.popularmovies1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.facebook.stetho.Stetho;
import com.facebook.stetho.inspector.database.ContentProviderSchema;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import br.com.popularmovies1.ruddy.popularmovies1.adapter.CustomListAdapter;
import br.com.popularmovies1.ruddy.popularmovies1.app.AppController;
import br.com.popularmovies1.ruddy.popularmovies1.app.EndlessScrollListener;
import br.com.popularmovies1.ruddy.popularmovies1.data.MovieContract;
import br.com.popularmovies1.ruddy.popularmovies1.model.Movie;
import br.com.popularmovies1.ruddy.popularmovies1.until.Constants;
import br.com.popularmovies1.ruddy.popularmovies1.until.Utility;
import butterknife.Bind;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {


    String title,theid, thumbnail, date_release , vote_average , overview;

    @Bind(R.id.loading)  TextView loading;
    @Bind(R.id.popular_movies_grid)  GridView gridView;

    SharedPreferences sp;


    // Log tag
    private static final String TAG = MainActivity.class.getSimpleName();


    private  String TYPE_OF_SORT;



    private List<Movie> movieList = new ArrayList<Movie>();
    private CustomListAdapter adapter;

    private boolean mTwoPane;

    private int paginacao = 1;
    private String paginacaoStr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ButterKnife.bind(this);
        Stetho.initializeWithDefaults(this);

        if (findViewById(R.id.movie_detail_container) != null) {
            mTwoPane = true;
        }

        adapter = new CustomListAdapter(this, movieList);
        gridView.setAdapter(adapter);


        gridView.setOnScrollListener(new EndlessScrollListener() {


            @Override
            public boolean onLoadMore(int page, int totalItemsCount) {
                // Triggered only when new data needs to be appended to the list
                // Add whatever code is needed to append new items to your AdapterView
                customLoadMoreDataFromApi(page);
                // or customLoadMoreDataFromApi(totalItemsCount);
                return true; // ONLY if more data is actually being loaded; false otherwise.
            }

            // Append more data into the adapter
            public void customLoadMoreDataFromApi(int offset) {


                paginacao += 1;


                createVoley(TYPE_OF_SORT);
            }
        });




        sp = PreferenceManager.getDefaultSharedPreferences(this);
        TYPE_OF_SORT = sp.getString(Constants.SORT_ORDER_TYPE, "");


        if (Utility.hasInternetAccess(MainActivity.this)) {

            if(TYPE_OF_SORT.equals(Constants.SORT_BY_FAV)) {

               // adapter.getMoviesList().clear();
                TYPE_OF_SORT = Constants.SORT_BY_FAV;
                showFavouriteMovies();

            }else if(TYPE_OF_SORT.equals(Constants.SORT_BY_MOST_RATED)) {

                TYPE_OF_SORT = Constants.SORT_BY_MOST_RATED;
                createVoley(TYPE_OF_SORT);

            }else{
                TYPE_OF_SORT = Constants.SORT_BY_POPULAR;
                createVoley(TYPE_OF_SORT);
            }

        } else {
            showSnackBar();
        }

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {


                Movie movieItem = (Movie) adapter.getItem(position);
                Intent intent = new Intent(MainActivity.this, MovieDetailsActivity.class);
                intent.putExtra(Constants.MOVIE, movieItem);
                startActivity(intent);
            }
        });



    }


    private void showSnackBar() {
        Snackbar.make(findViewById(android.R.id.content), "Check internet connectivity", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }

    public void createVoley(String type_of_sort) {

        loading.setVisibility(View.VISIBLE);

         paginacaoStr = String.valueOf(paginacao);

       Uri.Builder builder = new Uri.Builder();
        builder.scheme("https")
                .authority(Constants.URL_API_BASE)
                .appendPath("3")
                .appendPath("movie")
                .appendPath(TYPE_OF_SORT)
                .appendQueryParameter("api_key", Constants.API_KEY)
                .appendQueryParameter("language", "pt-BR")
                .appendQueryParameter("page", paginacaoStr);

        String URL_APP = builder.build().toString();

       //Log.d("Android", URL_APP);


      // String URL_APP = Constants.URL_API + TYPE_OF_SORT + "?api_key=" + Constants.API_KEY;

        // Creating volley request obj
        JsonObjectRequest movieReq = new JsonObjectRequest(Request.Method.GET, URL_APP, null,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {



                        try {

                            JSONArray results_array = response.getJSONArray("results");


                            // Parsing json
                            for (int i = 0; i < results_array.length(); i++) {


                                JSONObject jresponse = results_array.getJSONObject(i);


                                Movie movie = new Movie();

                                String theid = String.valueOf(jresponse.getInt("id"));
                                String titulo = jresponse.getString("original_title");
                                String poster_path = jresponse.getString("poster_path");
                                String thumbnail = Constants.ORIGIN_IMAGE + Constants.ORIGIN_IMAGE_SIZE + poster_path;
                                String vote_average = jresponse.getString("vote_average");
                                String date_release = jresponse.getString("release_date");
                                String overview = jresponse.getString("overview");

                                //JSONArray genre_ids_json = jresponse.getJSONArray("genre_ids");



                                String backdrop_path = jresponse.getString("backdrop_path");
                                String image_cover = Constants.ORIGIN_IMAGE + Constants.ORIGIN_IMAGE_SIZE_BACK + backdrop_path;

                                movie.setImageCoverUrl(image_cover);
                                movie.setTitle(titulo);
                                movie.setId(theid);
                                movie.setThumbnailUrl((thumbnail));

                                movie.setVoteAverage(vote_average);
                                movie.setDateRelease(date_release);
                                movie.setOverview(overview);

                                movieList.add(movie);

                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                        loading.setVisibility(View.GONE);

                        // notifying list adapter about data changes
                        // so that it renders the list view with updated data
                        adapter.notifyDataSetChanged();
                    }


                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                //hidePDialog();

            }

        }
        );


        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(movieReq);

    }



    private void showFavouriteMovies() {

        Cursor cursor = getContentResolver().query(MovieContract.MovieEntry.CONTENT_URI, null, null, null, MovieContract.MovieEntry._ID+" DESC");

        if (cursor != null) {

            int mTitle = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_TITLE);

            movieList.clear();

            try {


                while (cursor.moveToNext()) {

                    Movie movie = new Movie();

                    movie.setTitle(cursor.getString(mTitle));
                    movie.setThumbnailUrl(cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_POSTER_URL)));
                    movie.setImageCoverUrl(cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_BACK_DROP_URL)));
                    movie.setTitle(cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_ORIGINAL_TITLE)));
                    movie.setOverview(cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_PLOT)));
                    movie.setVoteAverage(cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_RATING)));
                    movie.setDateRelease(cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_RELEASE_DATE)));
                    movie.setId(cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_ID)));

                    movieList.add(movie);
                }
            }finally {

                adapter.notifyDataSetChanged();
                cursor.close();
            }


                //clearAdapter();
                // adapterFav.getMoviesList().addAll(mPosterList);


        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        SharedPreferences.Editor editor = sp.edit();

        //noinspection SimplifiableIfStatement
        if (id == R.id.most_popular) {

            movieList.clear();
            TYPE_OF_SORT = Constants.SORT_BY_POPULAR;
            editor.putString(Constants.SORT_ORDER_TYPE, Constants.SORT_BY_POPULAR);
            editor.apply();

            createVoley(TYPE_OF_SORT);

        } else if (id == R.id.highest_rated) {

            movieList.clear();
            TYPE_OF_SORT = Constants.SORT_BY_MOST_RATED;
            editor.putString(Constants.SORT_ORDER_TYPE, Constants.SORT_BY_MOST_RATED);
            editor.apply();

            createVoley(TYPE_OF_SORT);

        }else if (id == R.id.favourites) {

            TYPE_OF_SORT = Constants.SORT_BY_FAV;

            editor.putString(Constants.SORT_ORDER_TYPE, Constants.SORT_BY_FAV);
            editor.apply();

            showFavouriteMovies();

        }

        return super.onOptionsItemSelected(item);
    }
}
