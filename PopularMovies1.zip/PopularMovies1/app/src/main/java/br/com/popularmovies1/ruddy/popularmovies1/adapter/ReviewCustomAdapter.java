package br.com.popularmovies1.ruddy.popularmovies1.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;

import java.util.List;

import br.com.popularmovies1.ruddy.popularmovies1.R;
import br.com.popularmovies1.ruddy.popularmovies1.app.AppController;
import br.com.popularmovies1.ruddy.popularmovies1.model.Movie;
import br.com.popularmovies1.ruddy.popularmovies1.model.Review;

public class ReviewCustomAdapter extends BaseAdapter {
    private Activity activity;
    private LayoutInflater inflater;
    private List<Review> reviewItens;
    ImageLoader imageLoader = AppController.getInstance().getImageLoader();

    public ReviewCustomAdapter(Activity activity, List<Review> reviewItens) {
        this.activity = activity;
        this.reviewItens = reviewItens;
    }

    @Override
    public int getCount() {
        return reviewItens.size();
    }

    @Override
    public Object getItem(int location) {
        return reviewItens.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {



        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.reviews_list_item, null);

        if (imageLoader == null)
            imageLoader = AppController.getInstance().getImageLoader();


        TextView tv_theid = (TextView) convertView.findViewById(R.id.the_id);
        TextView author = (TextView) convertView.findViewById(R.id.author);
        TextView content = (TextView) convertView.findViewById(R.id.content);
        TextView url = (TextView) convertView.findViewById(R.id.url);


        // getting movie data for the row
        Review m = reviewItens.get(position);


        tv_theid.setText(m.getId());
        author.setText(m.getAuthor());
        content.setText(m.getContent());
        url.setText(m.getUrl());





        return convertView;
    }

}