package br.com.popularmovies1.ruddy.popularmovies1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import br.com.popularmovies1.ruddy.popularmovies1.adapter.CustomListAdapter;
import br.com.popularmovies1.ruddy.popularmovies1.adapter.ReviewCustomAdapter;
import br.com.popularmovies1.ruddy.popularmovies1.app.AppController;
import br.com.popularmovies1.ruddy.popularmovies1.model.Movie;
import br.com.popularmovies1.ruddy.popularmovies1.model.Review;
import br.com.popularmovies1.ruddy.popularmovies1.until.Constants;
import butterknife.Bind;
import butterknife.ButterKnife;

public class ReviewsActivity extends AppCompatActivity {


    // Log tag
    private static final String TAG = ReviewsActivity.class.getSimpleName();


    private List<Review> reviewList = new ArrayList<Review>();
    private ReviewCustomAdapter adapterReview;

    @Bind(R.id.review_movies)
    ListView listView;

    @Bind(R.id.loading) TextView loading;

    String theid,title;

    @Bind(R.id.tituloToolBar) TextView tituloToolBar;

    //String title,thumbnail, date_release , vote_average , overview;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviews);
       /* Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);*/

        ButterKnife.bind(this);

        inicializeScreen();


        loading = (TextView) findViewById(R.id.loading);
        listView = (ListView) findViewById(R.id.review_movies);
        adapterReview = new ReviewCustomAdapter(this, reviewList);
        listView.setAdapter(adapterReview);


        seeReviews();




    }

    public void goBack(View view){
        this.onBackPressed();
    }


    public void inicializeScreen(){
        Bundle data = getIntent().getExtras();
        Movie movie = (Movie) data.getParcelable(Constants.MOVIE);

        theid =  movie.getId();

        title = movie.getTitle();

        tituloToolBar.setText(getResources().getString(R.string.title_movie_review) + " " + title);
    }




    public void seeReviews(){



        loading.setVisibility(View.VISIBLE);



        String URL_APP_REVIEWS = Constants.URL_API + theid + "/reviews?api_key=" + Constants.API_KEY;

        //Log.d("Android", theid + " -  " + URL_APP_REVIEWS);

        // Creating volley request obj
        JsonObjectRequest movieReviewsReq = new JsonObjectRequest(Request.Method.GET, URL_APP_REVIEWS, null,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {


                        reviewList.clear();

                        try {

                            JSONArray results_array = response.getJSONArray("results");

                            Log.d("Android", String.valueOf(results_array.length()));


                            // Parsing json
                            for (int i = 0; i < results_array.length(); i++) {


                                JSONObject jresponse = results_array.getJSONObject(i);


                                Review review = new Review();


                                String review_theid =jresponse.getString("id");
                                String review_author = jresponse.getString("author");
                                String review_content = jresponse.getString("content");
                                String review_url = jresponse.getString("url");

                                review.setId(review_theid);
                                review.setAuthor(review_author);
                                review.setContent(review_content);
                                review.setUrl(review_url);



                                reviewList.add(review);



                            }


                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                        loading.setVisibility(View.GONE);
                        // notifying list adapter about data changes
                        // so that it renders the list view with updated data
                        adapterReview.notifyDataSetChanged();
                    }


                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d(TAG, "Error: " + error.getMessage());
                //hidePDialog();

            }

        }
        );


        // Adding request to request queue
        AppController.getInstance().addToRequestQueue(movieReviewsReq);





    }



}
