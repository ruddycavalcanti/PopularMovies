package br.com.popularmovies1.ruddy.popularmovies1.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import br.com.popularmovies1.ruddy.popularmovies1.app.AppController;
import br.com.popularmovies1.ruddy.popularmovies1.model.Movie;

import java.util.List;

import br.com.popularmovies1.ruddy.popularmovies1.R;

public class CustomListAdapter extends BaseAdapter {
    private Activity activity;
    private LayoutInflater inflater;
    private List<Movie> movieItems;
    ImageLoader imageLoader = AppController.getInstance().getImageLoader();

    public CustomListAdapter(Activity activity, List<Movie> movieItems) {
        this.activity = activity;
        this.movieItems = movieItems;
    }

    static class ViewHolder {
        TextView title;
        TextView theid;
        TextView date_release;
        TextView vote_average;
        TextView overview;
        NetworkImageView thumbNail;
        NetworkImageView imageCover;
        int position;
    }



    public List<Movie> getMoviesList() {
        return movieItems;
    }


    @Override
    public int getCount() {
        return movieItems.size();
    }

    @Override
    public Object getItem(int location) {
        return movieItems.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }



    @Override
    public View getView(int position, View convertView, ViewGroup parent) {



        if (inflater == null)
            inflater = (LayoutInflater) activity
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (convertView == null)
            convertView = inflater.inflate(R.layout.movies_list_item, null);

        if (imageLoader == null)
            imageLoader = AppController.getInstance().getImageLoader();



       ViewHolder holder = new ViewHolder();
        holder.thumbNail = (NetworkImageView) convertView.findViewById(R.id.thumbnail);
        holder.title = (TextView) convertView.findViewById(R.id.original_title);
        holder.theid = (TextView) convertView.findViewById(R.id.the_id);
        holder.date_release = (TextView) convertView.findViewById(R.id.date_release);
        holder.vote_average = (TextView) convertView.findViewById(R.id.vote_average);
        holder.overview = (TextView) convertView.findViewById(R.id.overview);
        holder.imageCover = (NetworkImageView) convertView.findViewById(R.id.imageCover);
        convertView.setTag(holder);


        // getting movie data for the row
        Movie m = movieItems.get(position);

        // thumbnail image
        holder.thumbNail.setImageUrl(m.getThumbnailUrl(), imageLoader);
        holder.title.setText(m.getTitle());
        holder.theid.setText(String.valueOf(m.getId()));
        holder.date_release.setText(m.getDateRelease());
        holder.vote_average.setText(m.getVoteAverage());
        holder.overview.setText(m.getOverview());
        holder.imageCover.setImageUrl(m.getImageCoverUrl(), imageLoader);




        return convertView;
    }

}