package br.com.popularmovies1.ruddy.popularmovies1.until;

/**
 * Constants class store most important strings and paths of the app
 */
public final class Constants {


    public static final String SORT_BY_POPULAR = "popular";
    public static final String SORT_BY_MOST_RATED = "top_rated";
    public static final String SORT_BY_FAV = "favourites";
    public static final String SORT_ORDER_TYPE = "sort_order_type";
    public static final String API_KEY = "efd6755f08c51db67a8f47a2623208e8";
    public static final String URL_API = "https://api.themoviedb.org/3/movie/";
    public static final String URL_API_BASE = "api.themoviedb.org";

    public static final String MOVIE = "movie";

    public static final String ORIGIN_IMAGE = "http://image.tmdb.org/t/p/";
    public static final String ORIGIN_IMAGE_SIZE = "w185";
    public static final String ORIGIN_IMAGE_SIZE_BACK = "w500";
}
