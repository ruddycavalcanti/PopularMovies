package br.com.popularmovies1.ruddy.popularmovies1;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import br.com.popularmovies1.ruddy.popularmovies1.until.Constants;


public class MovieDetailsActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);


        loadDetailsFragment(savedInstanceState);
    }

    private void loadDetailsFragment(Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            Bundle arguments = new Bundle();
            arguments.putParcelable(Constants.MOVIE, getIntent().getParcelableExtra(Constants.MOVIE));
            MovieDetailsFragment fragment = new MovieDetailsFragment();
            fragment.setArguments(arguments);
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.movie_detail_container, fragment)
                    .commit();
        }
    }

}
