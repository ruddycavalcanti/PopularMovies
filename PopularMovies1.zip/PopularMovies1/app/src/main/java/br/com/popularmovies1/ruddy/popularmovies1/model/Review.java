package br.com.popularmovies1.ruddy.popularmovies1.model;


import android.os.Parcel;
import android.os.Parcelable;

public class Review implements Parcelable {

    private String theid,author, content, url;


    public Review() {
    }

    public Review(String theid, String author, String content, String url) {
        this.theid = theid;
        this.author = author;
        this.content = content;
        this.url = url;
    }



    public String getId() {
        return theid;
    }

    public void setId(String theid) {
        this.theid = theid;
    }


    public String getAuthor() {  return author;  }

    public void setAuthor(String author) {
        this.author = author;
    }



    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }





    public String getUrl() {  return url;  }

    public void setUrl(String url) {
        this.url = url;
    }






    // Parcelling part
    public Review(Parcel in){
        String[] data = new String[4];

        in.readStringArray(data);
        this.theid =  data[0];
        this.author = data[1];
        this.content =  data[2];
        this.url =  data[3];
    }

    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[]{
                this.theid,
                this.author,
                this.content,
                this.url});
    }

   public static final Creator CREATOR = new Creator() {
        public Review createFromParcel(Parcel in) {
            return new Review(in);
        }

        public Review[] newArray(int size) {
            return new Review[size];
        }
    };


}