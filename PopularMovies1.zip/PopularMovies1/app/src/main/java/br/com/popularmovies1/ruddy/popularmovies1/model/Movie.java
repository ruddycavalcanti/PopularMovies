package br.com.popularmovies1.ruddy.popularmovies1.model;


import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {

    private String theid,title, thumbnailUrl, date_release, vote_average,overview, imageCoverUrl, genre_ids;


    public Movie() {
    }

    public Movie(String theid,String title, String thumbnailUrl, String date_release  , String vote_average, String overview, String imageCoverUrl) {
        this.theid = theid;
        this.title = title;
        this.thumbnailUrl = thumbnailUrl;
        this.date_release = date_release;
        this.vote_average = vote_average;
        this.overview = overview;
        this.imageCoverUrl = imageCoverUrl;
    }

    public String getId() {
        return theid;
    }

    public void setId(String theid) {
        this.theid = theid;
    }


    public String getTitle() {  return title;  }

    public void setTitle(String title) {
        this.title = title;
    }



    public String getThumbnailUrl() {
        return thumbnailUrl;
    }

    public void setThumbnailUrl(String thumbnailUrl) {
        this.thumbnailUrl = thumbnailUrl;
    }





    public String getDateRelease() {  return date_release;  }

    public void setDateRelease(String date_release) {
        this.date_release = date_release;
    }



    public String getVoteAverage() {  return vote_average;  }

    public void  setVoteAverage(String vote_average) {
        this.vote_average = vote_average;
    }



    public String getOverview() {  return overview;  }

    public void setOverview(String overview) {
        this.overview = overview;
    }



    public String getImageCoverUrl() {  return imageCoverUrl;  }

    public void setImageCoverUrl(String imageCoverUrl) {
        this.imageCoverUrl = imageCoverUrl;
    }




    // Parcelling part
    public Movie(Parcel in){
        String[] data = new String[7];

        in.readStringArray(data);
        this.theid =  data[0];
        this.title = data[1];
        this.thumbnailUrl =  data[2];
        this.date_release =  data[3];
        this.vote_average =  data[4];
        this.overview =  data[5];
        this.imageCoverUrl =  data[6];
    }

    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[]{
                this.theid,
                this.title,
                this.thumbnailUrl,
                this.date_release,
                this.vote_average,
                this.overview,
                this.imageCoverUrl});
    }

   public static final Parcelable.Creator CREATOR = new Parcelable.Creator() {
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };


}