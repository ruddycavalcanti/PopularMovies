package br.com.popularmovies1.ruddy.popularmovies1.model;


import android.os.Parcel;
import android.os.Parcelable;

public class Video implements Parcelable {

    private String vName,vKey,vThumbnailUrl;


    public Video() {
    }

    public Video(String vName, String vKey, String vThumbnailUrl) {
        this.vName = vName;
        this.vKey = vKey;
        this.vThumbnailUrl = vThumbnailUrl;
    }



    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }


    public String getvKey() {  return vKey;  }

    public void setvKey(String vKey) {
        this.vKey = vKey;
    }







    // Parcelling part
    public Video(Parcel in){
        String[] data = new String[2];

        in.readStringArray(data);
        this.vName =  data[0];
        this.vKey = data[1];
    }

    @Override
    public int describeContents(){
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeStringArray(new String[]{
                this.vName,
                this.vKey});
    }

   public static final Creator CREATOR = new Creator() {
        public Video createFromParcel(Parcel in) {
            return new Video(in);
        }

        public Video[] newArray(int size) {
            return new Video[size];
        }
    };


}