package br.com.popularmovies1.ruddy.popularmovies1.until;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;

public class Utility {

    /**
     * Checks for internet access
     *
     * @param context context
     * @return hasInternet boolean
     */
    public static boolean hasInternetAccess(@NonNull Context context) {
        try {
            boolean hasInternet = false;

            ConnectivityManager cm = (ConnectivityManager) context
                    .getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo networkInfo = cm.getActiveNetworkInfo();
            NetworkInfo wifi = cm
                    .getNetworkInfo(ConnectivityManager.TYPE_WIFI);
            NetworkInfo mobile = cm
                    .getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
            if ((wifi.isAvailable() || mobile.isAvailable())
                    && networkInfo != null
                    && networkInfo.isConnectedOrConnecting()) {

                hasInternet = true;
            }

            return hasInternet;
        } catch (Exception e) {
            return false;
        }
    }
}
