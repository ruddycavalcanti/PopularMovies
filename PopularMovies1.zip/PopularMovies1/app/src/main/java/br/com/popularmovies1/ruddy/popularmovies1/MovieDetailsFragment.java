package br.com.popularmovies1.ruddy.popularmovies1;


import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.NetworkImageView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import br.com.popularmovies1.ruddy.popularmovies1.app.AppController;
import br.com.popularmovies1.ruddy.popularmovies1.data.MovieContract;
import br.com.popularmovies1.ruddy.popularmovies1.model.Movie;
import br.com.popularmovies1.ruddy.popularmovies1.model.Video;
import br.com.popularmovies1.ruddy.popularmovies1.until.Constants;
import butterknife.Bind;
import butterknife.ButterKnife;

public class MovieDetailsFragment extends Fragment {

    private static final String TAG = MovieDetailsFragment.class.getSimpleName();

    String theid, videoKey, videoName, videoImage, title;

    @Bind(R.id.original_title)
    TextView text_title;
    @Bind(R.id.the_id)
    TextView text_theid;
    @Bind(R.id.date_release)
    TextView text_date_release;
    @Bind(R.id.vote_average)
    TextView text_vote_average;
    @Bind(R.id.overview)
    TextView text_overview;
    @Bind(R.id.thumbnail)
    NetworkImageView text_thumbnail;
    @Bind(R.id.imageCover)
    NetworkImageView text_image_cover;

    @Bind(R.id.seeReviews)
    Button seeReviews;
    @Bind(R.id.markAsFavorite)
    Button markAsFavorite;


    @Bind(R.id.trailers)
        LinearLayout mTrailersView;

        @Bind(R.id.trailers_container)
        HorizontalScrollView trailers_container;

        @Bind(R.id.trailers_label)
        TextView trailers_label;

        Movie moviesResponse;
        Toolbar mToolbar = null;
        private List<Video> videosList = new ArrayList<Video>();
        private boolean isFavourite = false;
        private ContentValues values;


        public MovieDetailsFragment() {
            // Required empty public constructor
        }


        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            if (getArguments().containsKey(Constants.MOVIE)) {
                moviesResponse = getArguments().getParcelable(Constants.MOVIE);
            }
            //Log.d("Android", String.valueOf(moviesResponse));
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_movie_details, container, false);

            ButterKnife.bind(this, rootView);

            mToolbar = (Toolbar) rootView.findViewById(R.id.toolbar);

            ((AppCompatActivity) getActivity()).setSupportActionBar(mToolbar);
            ((AppCompatActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle(moviesResponse.getTitle());


            markAsFavorite.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    markAsFavorite();
                }
            });

            seeReviews.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    seeReviews();
                }
            });






            return rootView;
        }

        @Override
        public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
            super.onViewCreated(view, savedInstanceState);

            inicializeScreen();

            fetchTrailers();

            createContentValues();
        }


        public void inicializeScreen() {


            theid = moviesResponse.getId();
            title = moviesResponse.getTitle();
            ImageLoader imageLoader = AppController.getInstance().getImageLoader();
            String bitmap = moviesResponse.getThumbnailUrl();
            String date_release = moviesResponse.getDateRelease();
            String vote_average = moviesResponse.getVoteAverage();
            String overview = moviesResponse.getOverview();
            String image_cover = moviesResponse.getImageCoverUrl();

            text_theid.setText(theid);
            text_title.setText(title);
            text_thumbnail.setImageUrl(bitmap, imageLoader);
            text_image_cover.setImageUrl(image_cover, imageLoader);

            date_release = date_release.substring(0, 4);
            text_date_release.setText(date_release);
            text_vote_average.setText(vote_average + "/10");
            text_overview.setText(overview);


        }



        public void fetchTrailers() {
            String URL_APP = Constants.URL_API + theid + "/videos?api_key=" + Constants.API_KEY;

            JsonObjectRequest movieReq = new JsonObjectRequest(Request.Method.GET, URL_APP, null,
                    new Response.Listener<JSONObject>() {

                        @Override
                        public void onResponse(JSONObject response) {
                            try {

                                JSONArray results_array = response.getJSONArray("results");

                                for (int i = 0; i < results_array.length(); i++) {

                                    JSONObject jresponse = results_array.getJSONObject(i);


                                    Video video = new Video();

                                    videoName = jresponse.getString("name");
                                    videoKey = jresponse.getString("key");
                                    ///*getResources().getString(R.string.watch_trailer) + */": " +

                                    video.setvName(videoName);
                                    video.setvKey(videoKey);

                                    videosList.add(video);

                                    // textViewVideoName.setText(dataVideoName);
                                    //textViewVideoKey.setText(dataVideoKey);


                                }


                            } catch (JSONException e) {
                                e.printStackTrace();
                            }


                            showTrailers(videosList);




                        }


                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    VolleyLog.d(TAG, "Error: " + error.getMessage());


                }

            }
            );


            // Adding request to request queue
            AppController.getInstance().addToRequestQueue(movieReq);

        }


        public void showTrailers(List<Video> trailers) {

            LayoutInflater inflater = getActivity().getLayoutInflater();

            TextView videoNameTV;
            TextView videoKeyTV;
            ImageView videoImageView;


            for (Video trailer : trailers) {

                //Log.d("Android", trailer.getvName());

                if (trailers.isEmpty()) {
                    trailers_label.setVisibility(View.GONE);
                    trailers_container.setVisibility(View.GONE);
                    mTrailersView.setVisibility(View.GONE);
                } else {

                    trailers_label.setVisibility(View.VISIBLE);
                    trailers_container.setVisibility(View.VISIBLE);
                    mTrailersView.setVisibility(View.VISIBLE);

                    ViewGroup thumbContainer = (ViewGroup) inflater.inflate(R.layout.video_list_item, mTrailersView, false);

                     videoNameTV = (TextView) thumbContainer.findViewById(R.id.videoName);
                     videoKeyTV = (TextView) thumbContainer.findViewById(R.id.videoKey);
                     videoImageView = (ImageView) thumbContainer.findViewById(R.id.videoImage);

                    videoName = trailer.getvName();
                    videoKey = trailer.getvKey();
                    videoImage = "http://img.youtube.com/vi/" + trailer.getvKey() + "/0.jpg";

                    videoNameTV.setText(videoName);
                    videoKeyTV.setText(videoKey);
                    Picasso.with(getActivity()).load(videoImage).into(videoImageView);

                    videoNameTV.requestLayout();
                    videoKeyTV.requestLayout();

                    mTrailersView.addView(thumbContainer);


                    final String videoKeyFinal = videoKeyTV.getText().toString();
                    //Log.d("Android", videoKeyFinal);
                    videoImageView.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            //shareVideos();
                           // Log.d("Android2", videoKeyFinal);
                            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com/watch?v=" + videoKeyFinal)));

                        }
                    });
                    //shareVideos(trailers);
                }

            }








    }

    /*private void shareVideos(List<Video> trailers) {

        Log.d("Android", String.valueOf(videosList));

        for (Video trailer : trailers) {
            try {
                if (videosList != null) {

                    String videoKey = trailer.getvKey();
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.youtube.com/watch?v=" + videoKey)));

                }
            } catch (IndexOutOfBoundsException ignored) {
            }
        }



    }*/

    public void createContentValues() {
        values = new ContentValues();
        if (moviesResponse.getThumbnailUrl() == null) {
            moviesResponse.setThumbnailUrl("No url found");
        }

        values.put(MovieContract.MovieEntry.COLUMN_TITLE, moviesResponse.getTitle());
        values.put(MovieContract.MovieEntry.COLUMN_POSTER_URL, moviesResponse.getThumbnailUrl());
        values.put(MovieContract.MovieEntry.COLUMN_BACK_DROP_URL, moviesResponse.getImageCoverUrl());
        values.put(MovieContract.MovieEntry.COLUMN_ORIGINAL_TITLE, moviesResponse.getTitle());
        values.put(MovieContract.MovieEntry.COLUMN_PLOT, moviesResponse.getOverview());
        values.put(MovieContract.MovieEntry.COLUMN_RATING, moviesResponse.getVoteAverage());
        values.put(MovieContract.MovieEntry.COLUMN_RELEASE_DATE, moviesResponse.getDateRelease());
        values.put(MovieContract.MovieEntry.COLUMN_MOVIE_ID, moviesResponse.getId());
        values.put(MovieContract.MovieEntry.COLUMN_GENRE_ID, moviesResponse.getDateRelease());

        Cursor c = getActivity().getContentResolver().
                query(MovieContract.MovieEntry.CONTENT_URI,
                        new String[]{MovieContract.MovieEntry.COLUMN_MOVIE_ID},
                        MovieContract.MovieEntry.COLUMN_MOVIE_ID + "= ? ",
                        new String[]{String.valueOf(moviesResponse.getId())},
                        null);

        if (c != null) {
            if (c.getCount() > 0) {
                showFavourites();

            } else {
                showUnFavourites();
            }
            c.close();
        }
    }


    public void seeReviews() {
        Intent intent = new Intent(getActivity(), ReviewsActivity.class);
        intent.putExtra(Constants.MOVIE, new Movie(theid, title, "", "", "", "", ""));
        startActivity(intent);
    }


    public void markAsFavorite() {
        if (isFavourite) {
            int rowDeleted = getActivity().getContentResolver().delete(MovieContract.MovieEntry.CONTENT_URI,
                    MovieContract.MovieEntry.COLUMN_MOVIE_ID + "= ?", new String[]{String.valueOf(moviesResponse.getId())});
            if (rowDeleted > 0) {
                showUnFavourites();
                showSnackBar("Removed " + moviesResponse.getTitle() + " from favourites");
            }
        } else {
            Uri rowUri = getActivity().getContentResolver().insert(MovieContract.MovieEntry.CONTENT_URI, values);
            long rowId = ContentUris.parseId(rowUri);
            if (rowId > 0) {
                showFavourites();
                showSnackBar("Added " + moviesResponse.getTitle() + " to favourites");
            }
        }
    }


    public void showFavourites() {
        isFavourite = true;
        markAsFavorite.setText(getActivity().getResources().getString(R.string.liked));

    }

    public void showUnFavourites() {
        isFavourite = false;
        markAsFavorite.setText(getActivity().getResources().getString(R.string.mark_as_favorite));

    }

    private void showSnackBar(@NonNull String message) {
        Snackbar.make(getActivity().findViewById(android.R.id.content), message, Snackbar.LENGTH_SHORT)
                .setAction("Action", null).show();
    }


}
